package poly.store.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import poly.store.entity.Category;
import poly.store.entity.Product;
import poly.store.service.CategoryService;
import poly.store.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService productService;
	@Autowired
	CategoryService categoryService;
	@RequestMapping("/product/list")
	public String list(Model model,@RequestParam("cid") Optional<String> cid) {
		if (cid.isPresent()) {
			List<Product> list = productService.findByCategoryId(cid.get());
			model.addAttribute("items",list);
		}else {
			List<Product> list = productService.findAll();
			model.addAttribute("items",list);
		}
		
		
		return "product/list";
	}
	
	@RequestMapping("/product/detail/{id}")
	public String detail(Model model, @PathVariable("id") Integer id) {
		Product pro = productService.findById(id);
		model.addAttribute("product",pro);
		return "product/detail";
	}
	
	@RequestMapping("product/search")
	public String search(Model model, @RequestParam("search") String search ) {
		if(search==null) {
			return "redirect:/index";
		}
		Category ca=categoryService.findByName(search);
		List<Product> items = productService.findByNameContainingOrCategory(search,ca);
		model.addAttribute("items", items);
		
		return "product/list";
	}
}
