package poly.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class J6StoreFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(J6StoreFinalApplication.class, args);
	}

}
