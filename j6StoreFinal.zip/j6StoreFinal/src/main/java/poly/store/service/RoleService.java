package poly.store.service;

import java.util.List;

import poly.store.entity.Role;

public interface RoleService {

	public List<Role> findAll();

}
